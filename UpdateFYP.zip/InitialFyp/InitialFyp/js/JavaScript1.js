﻿function ShowTaxiDetail() {
    var x = document.getElementById("Taxidetail");

    if (x.style.display == "none") {
        x.style.display = "block";

    }
    else if (x.style.display == "block") {
        x.style.display = "none";
    }
    else {
        x.style.display = "none";
    }
};
function ShowBusDetail() {
    var x = document.getElementById("Busdetail");

    if (x.style.display == "none") {
        x.style.display = "block";

    }
    else if (x.style.display == "block") {
        x.style.display = "none";
    }
    else {
        x.style.display = "none";
    }
};
function ShowTrainDetail() {
    var x = document.getElementById("Traindetail");

    if (x.style.display == "none") {
        x.style.display = "block";

    }
    else if (x.style.display == "block") {
        x.style.display = "none";
    }
    else {
        x.style.display = "none";
    }
};
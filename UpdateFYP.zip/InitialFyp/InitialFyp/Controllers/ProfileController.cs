﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InitialFyp.Models;

namespace InitialFyp.Controllers
{
    public class ProfileController : Controller
    {
        //
        // GET: /Profile/
        public ActionResult ViewProfile()
        {
            return View();
        }
        [HttpPost]
        public ActionResult ViewProfile(FormCollection f)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            Profile p1 = new Profile();
            Profile p = new Profile();
            User u = Session["user"] as User;
            p1 = obj.Profiles.FirstOrDefault(x => x.Id == u.Id);
            if (p1 == null)
            {

                p.Id = u.Id;
                p.Name = f["Name"];
                p.Password = f["Password"];
                p.Email = f["Email"];
                p.City = f["City"];
                p.CNIC = f["CNIC"];
                p.Nationality = f["Nationality"];
                obj.Profiles.Add(p);
                //obj.Entry(p).State = System.Data.EntityState.Modified;
                obj.SaveChanges();

            }
            else if (p1 != null)
            {
                return RedirectToAction("SuccessComplete");
            }
            return View();
        }
        public ActionResult ForgotPassword()
        {

            return View();

        }
        public ActionResult ShowProfile(Profile p)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            User u = Session["user"] as User;
            p = obj.Profiles.FirstOrDefault(x => x.Id == u.Id);
           
            return View(p);
        }
        public ActionResult CompleteProfile(int id)
        {

            MyDbEntities1 obj = new MyDbEntities1();
            User u = Session["user"] as User;
            
            User x = obj.Users.FirstOrDefault(s => s.Name == u.Name && s.Password == u.Password);
            Profile p = obj.Profiles.FirstOrDefault(y => y.Id == id);
            //var z = obj.Profiles.Where(y => y.Id.Equals(id));

            if (p == null)
            {
                return View(x);
            }
            else
            {
                return RedirectToAction("../Profile/SuccessComplete");
            }

        }
        public ActionResult UpdateProfile()
        {
            User u = Session["user"] as User;
            return View();
        }
        public ActionResult SuccessComplete()
        {

            return View();

        }
        public ActionResult User_ViewEconomyHotels(HotelsInfo h)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            var hotel = obj.HotelsInfoes.Where(x => x.HotelClass == "Economy").ToList();
            return View(hotel);
            
        }
        public ActionResult User_ViewStarHotels(HotelsInfo h)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            var hotel = obj.HotelsInfoes.Where(x => x.HotelClass == "Star").ToList();
            return View(hotel);
        }
        public ActionResult User_ViewLuxuryHotels(HotelsInfo h)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            var hotel = obj.HotelsInfoes.Where(x => x.HotelClass == "Luxuries").ToList();
            return View(hotel);
        }
        public ActionResult User_ViewTaxiList(Transport t)
        {
            MyDbEntities1 obj = new MyDbEntities1();

            var drafts = obj.Transports.Where(x => x.TransportType == "Taxi").ToList();
            return View(drafts);
        }
        public ActionResult User_ViewBusList(Transport t)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            var drafts = obj.Transports.Where(d => d.TransportType == "Bus").ToList();
            return View(drafts);
        }
        public ActionResult User_ViewTrainList(Transport t)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            var drafts = obj.Transports.Where(d => d.TransportType == "Train").ToList();
            return View(drafts);
        }
        public ActionResult User_ViewPark(VisitingPlace vp)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            var VisitingPlace = obj.VisitingPlaces.Where(x => x.PlaceType == "Park").ToList();
            return View(VisitingPlace);
        }
        public ActionResult User_ViewSeaPort(VisitingPlace vp)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            var VisitingPlace = obj.VisitingPlaces.Where(x => x.PlaceType == "SeaPort").ToList();
            return View(VisitingPlace);
        }
        public ActionResult User_ShoppingMall(VisitingPlace vp)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            var VisitingPlace = obj.VisitingPlaces.Where(x => x.PlaceType == "ShoppingMall").ToList();
            return View(VisitingPlace);
        }
      
    }

}

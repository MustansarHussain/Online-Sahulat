﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InitialFyp.Models;
namespace InitialFyp.Controllers
{
    public class TransportController : Controller
    {
        //
        // GET: /Transport/

        public ActionResult TransportMain()
        {
            User b = Session["user"] as User;
            Session.Clear();
            @ViewBag.b = b;
            return View();
        }

        public ActionResult AddTransport()
        {

            return View();
        }
        [HttpPost]
        public ActionResult AddTransport(Transport t, HttpPostedFileBase file)
        {
            if (file != null)
            {
                MyDbEntities1 obj = new MyDbEntities1();
                string ImageName = System.IO.Path.GetFileName(file.FileName);
                string physicalPath = Server.MapPath("~/TransportImage/" + ImageName);
                // save image in folder
                file.SaveAs(physicalPath);
                t.ImageUrl = ImageName;  
                obj.Transports.Add(t);
                obj.SaveChanges();
                return RedirectToAction("../Admin/AdminMain");
            }
            else
            {

                return RedirectToAction("../Admin/AdminMain");
                
            }
        }

        public ActionResult ViewTransport()
        {
            MyDbEntities1 obj = new MyDbEntities1();
            Transport t = new Transport();
            List<Transport> mylist = obj.Transports.ToList();
            return View(mylist);
        }
        public ActionResult UpdateTransport(int id)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            Transport t = new Transport();
            t = obj.Transports.Find(id);
            
            return View(t);
        }
        [HttpPost]
        public ActionResult UpdateTransport(Transport t)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            if (ModelState.IsValid)
            {
                obj.Entry(t).State = System.Data.EntityState.Modified;
                obj.SaveChanges();
                return RedirectToAction("../Admin/AdminMain");  
            }
            return View(t);
        }
        public ActionResult DeleteTransport(int id)
        {
            MyDbEntities1 obj=new MyDbEntities1();
            Transport t = new Transport();
            t = obj.Transports.Find(id);
            obj.Transports.Remove(t);
            obj.SaveChanges();
            return RedirectToAction("../Admin/AdminMain");

        }
       
        public ActionResult SelectTransport()
        {
            return View();
        }
        public ActionResult ConveyanceReservation()
        {
            return View();
        }
        public ActionResult  ViewTaxiList(Transport t)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            
            var drafts = obj.Transports.Where(x => x.TransportType == "Taxi").ToList();
            return View(drafts);
        }
        public ActionResult ViewBusList(Transport t)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            var drafts = obj.Transports.Where(d => d.TransportType == "Bus").ToList();
            return View(drafts);
        }
        public ActionResult ViewTrainList(Transport t)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            var drafts = obj.Transports.Where(d => d.TransportType == "Train").ToList();
            return View(drafts);
        }
    }

}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InitialFyp.Models;
namespace InitialFyp.Controllers
{
    public class BookingController : Controller
    {
        MyDbEntities1 obj = new MyDbEntities1();
        //
        // GET: /Booking/

        public ActionResult BookingMain()
        {
            

            return View();
        }
        public ActionResult BookingFormNo()
        {
            return View();
        }
        public ActionResult ViewBooking(string Booking_Id)
        {
            Booking b = new Booking();
            int bid = Convert.ToInt32(Booking_Id);
            b = obj.Bookings.Find(bid);
            if (b != null)
            {
                return View(b);
            }
            else {
                @ViewBag.Error = "Sorry Your Booking has been Canceled!";
                return View();
            }
               
            
         
        }
        [HttpGet]
        public ActionResult TransportBooking()
        {
           
           
            return View();
        }
      
        [HttpPost]
        public ActionResult TransportBooking(Booking b)
        {
            Session["book"] = b;
            obj.Bookings.Add(b);
            obj.SaveChanges();
            if (ModelState.IsValid)
            {
                var senderMail = new System.Net.Mail.MailAddress("mustansarhussain016@gmail.com");
                var recieverMail = new System.Net.Mail.MailAddress(b.Email, "Reciever");
                var password = "uos_starwar";
                var sub = "Booking Confirmation";
                var message = "Thank you so much for using our services And Your Booking Form No is"+b.Booking_Id;
                var smtp = new System.Net.Mail.SmtpClient
                {
                    Host = "smtp.gmail.com",
                    Port = 587,
                    EnableSsl = true,
                    DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network,
                    UseDefaultCredentials = false,
                    Credentials = new System.Net.NetworkCredential(senderMail.Address, password)

                };
                using (var message1 = new System.Net.Mail.MailMessage(senderMail, recieverMail)
                {
                    Subject = sub,
                    Body = message

                })
                {
                    smtp.Send(message1);
                }

            


            }
          
            return RedirectToAction("../Booking/Success");
        }
        public ActionResult success(Booking b)
        {
            b = Session["book"] as Booking;
            return View(b);
        }
        public ActionResult Delete(Booking b,int id)
        {
            b = Session["book"] as Booking;
            
           Booking b1=obj.Bookings.Find(id);
           Booking b2 = b1;
           if (b1 != null)
           {
               obj.Bookings.Remove(b1);
               obj.SaveChanges();
               if (ModelState.IsValid)
               {
                   var senderMail = new System.Net.Mail.MailAddress("mustansarhussain016@gmail.com");
                   var recieverMail = new System.Net.Mail.MailAddress(b2.Email, "Reciever");
                   var password = "uos_starwar";
                   var sub = "Booking Confirmation";
                   var message = "Your Booking Has been Canceled Succefully";
                   var smtp = new System.Net.Mail.SmtpClient
                   {
                       Host = "smtp.gmail.com",
                       Port = 587,
                       EnableSsl = true,
                       DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network,
                       UseDefaultCredentials = false,
                       Credentials = new System.Net.NetworkCredential(senderMail.Address, password)

                   };
                   using (var message1 = new System.Net.Mail.MailMessage(senderMail, recieverMail)
                   {
                       Subject = sub,
                       Body = message

                   })
                   {
                       smtp.Send(message1);
                   }




               }
              
            

           }
           else {
               return RedirectToAction("/Booking/PageDelete");
           }
         
            return View(b);
           
            
        }
        public ActionResult PageDelete()
        {
            return View();
        }
        public ActionResult UserVarification()
        {
            return View();
        }
        public ActionResult Edit(Booking b, int id)
        {
            Booking b1 = obj.Bookings.Find(id);
            if (b1 != null)
            {
                return View(b1);
            }
            else
            {
                return View();
            }
           
        }
        [HttpPost]
        public ActionResult Edit(Booking b)
        {
            
            obj.Entry(b).State = System.Data.EntityState.Modified;
            obj.SaveChanges();
            return RedirectToAction("../Booking/EditSuccess");
        }
        public ActionResult EditSuccess()
        {
            return View();
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InitialFyp.Models;
namespace InitialFyp.Controllers
{
    public class LoginController : Controller
    {
        //
        // GET: /Login/

        public ActionResult Index()
        {
            
            return View();
        }
        public ActionResult SignIn()
        {
            return View();
        }
        public ActionResult SignUp()
        {
            return View();
        }
        public ActionResult ChangePassword()
        {
            return View();
        }
        public ActionResult Logins()
        {
            return View();
        }
        public ActionResult Success(User u)
        {
            MyDbEntities1 obj = new MyDbEntities1();            
            obj.Users.Add(u);
            obj.SaveChanges();
            ViewBag.name = u.Name;
            return View();
        
        }
        public ActionResult GoHome()
        {
            User u = Session["user"] as User;
            return View(u);
        }
        public ActionResult LoginSuccess(User u)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            
            if (u.Name == "Ali" && u.Password == "1234")
            {
                return RedirectToAction("../Admin/AdminMain");
            }
            else
            {
                User a = obj.Users.FirstOrDefault(x => x.Name == u.Name && x.Password == u.Password);
                if (a == null)
                {

                    return RedirectToAction("Index", "Login");
                }
                else if (a != null)
                {
                    Session["user"] = a;
                   

                    return View(a);
                }
                else {
                    return View();
                }
                
            }
        }
        public ActionResult SignOut()
        {
            Session.Clear();
            return View();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InitialFyp.Models;
namespace InitialFyp.Controllers
{
    public class AdminController : Controller
    {
        //
        // GET: /Admin/

        public ActionResult AdminMain()
        {
            return View();
        }
        public ActionResult Admin_MainHotel()
        {
            return View();
        }
        public ActionResult Admin_MainTransport()
        {
            return View();
        }
        public ActionResult Admin_MainVisitingPlaces()
        {
            return View();
        }
        public ActionResult Admin_ViewLuxuryHotels(HotelsInfo h)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            var hotel = obj.HotelsInfoes.Where(x => x.HotelClass == "Luxuries").ToList();
            return View(hotel);
        }
        public ActionResult Admin_ViewEconomyHotels(HotelsInfo h)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            var hotel = obj.HotelsInfoes.Where(x => x.HotelClass == "Economy").ToList();
            return View(hotel);
        }
        public ActionResult Admin_ViewStarHotels(HotelsInfo h)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            var hotel = obj.HotelsInfoes.Where(x => x.HotelClass == "Star").ToList();
            return View(hotel);
        }
        public ActionResult Admin_ViewTaxiList(Transport t)
        {
            MyDbEntities1 obj = new MyDbEntities1();

            var drafts = obj.Transports.Where(x => x.TransportType == "Taxi").ToList();
            return View(drafts);
        }
        public ActionResult Admin_ViewBusList(Transport t)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            var drafts = obj.Transports.Where(d => d.TransportType == "Bus").ToList();
            return View(drafts);
        }
        public ActionResult Admin_ViewTrainList(Transport t)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            var drafts = obj.Transports.Where(d => d.TransportType == "Train").ToList();
            return View(drafts);
        }
        public ActionResult Admin_ViewPark(VisitingPlace vp)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            var VisitingPlace = obj.VisitingPlaces.Where(x => x.PlaceType == "Park").ToList();
            return View(VisitingPlace);
        }
        public ActionResult Admin_ViewSeaPort(VisitingPlace vp)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            var VisitingPlace = obj.VisitingPlaces.Where(x => x.PlaceType == "SeaPort").ToList();
            return View(VisitingPlace);
        }
        public ActionResult Admin_ShoppingMall(VisitingPlace vp)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            var VisitingPlace = obj.VisitingPlaces.Where(x => x.PlaceType == "ShoppingMall").ToList();
            return View(VisitingPlace);
        }
        public ActionResult ViewBooking()
        {
            MyDbEntities1 obj = new MyDbEntities1();
            Booking b = new Booking();
            
            List<Booking> booking = obj.Bookings.ToList();
            Session["AdminBooking"] = booking;
                if (booking != null)
                {
                    return View(booking);
                }
                else
                {
                    @ViewBag.Error = "No Result Found!";
                    return RedirectToAction("/Admin/AdminMain");
                }



        }
        public ActionResult NoResult()
        {
            return View();
        }
        public ActionResult ConfirmBooking(int id)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            Booking b = new Booking();
            b = obj.Bookings.Find(id);
            Booking b1 = b;
            if (b != null)
            {
                b.Status = "Confirm";
                obj.Entry(b).State = System.Data.EntityState.Modified;
                obj.SaveChanges();
            }
            if (ModelState.IsValid)
            {
                var senderMail = new System.Net.Mail.MailAddress("mustansarhussain016@gmail.com");
                var recieverMail = new System.Net.Mail.MailAddress(b1.Email, "Reciever");
                var password = "uos_starwar";
                var sub = "Booking Confirmation";
                var message = "Congratulation your Booking Has been Confirmed ";
                var smtp = new System.Net.Mail.SmtpClient
                {
                    Host = "smtp.gmail.com",
                    Port = 587,
                    EnableSsl = true,
                    DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network,
                    UseDefaultCredentials = false,
                    Credentials = new System.Net.NetworkCredential(senderMail.Address, password)

                };
                using (var message1 = new System.Net.Mail.MailMessage(senderMail, recieverMail)
                {
                    Subject = sub,
                    Body = message

                })
                {
                    smtp.Send(message1);
                }
            }



            
            return RedirectToAction("../Admin/ViewBooking");
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InitialFyp.Models;
namespace InitialFyp.Controllers
{
    public class HotelsController : Controller
    {
        //
        // GET: /Hotels/

        public ActionResult HotelsMian()
        {
            User b = Session["user"] as User;
            Session.Clear();
            @ViewBag.b = b;
            return View();
        }
        public ActionResult AddHotels()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddHotels(HotelsInfo h,HttpPostedFileBase file)
        {
            if (file != null)
            {
                MyDbEntities1 obj = new MyDbEntities1();
                string ImageName = System.IO.Path.GetFileName(file.FileName);
                string physicalPath = Server.MapPath("~/HotelsImage/" + ImageName);
                // save image in folder
                file.SaveAs(physicalPath);
                h.ImageUrl = ImageName;
                obj.HotelsInfoes.Add(h);
                obj.SaveChanges();
                return RedirectToAction("../Admin/AdminMain");
            }
            else
            {

                return View();
                
            }
           
        }
        public ActionResult ViewHotels()
        {
            MyDbEntities1 obj = new MyDbEntities1();
            HotelsInfo t = new HotelsInfo();
            List<HotelsInfo> mylist = obj.HotelsInfoes.ToList();
            return View(mylist);
        }
        public ActionResult ViewLuxuryHotels(HotelsInfo h)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            var hotel = obj.HotelsInfoes.Where(x => x.HotelClass == "Luxuries").ToList();
            return View(hotel);
        }
        public ActionResult ViewEconomyHotels(HotelsInfo h)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            var hotel = obj.HotelsInfoes.Where(x => x.HotelClass == "Economy").ToList();
            return View(hotel);
        }
        public ActionResult ViewStarHotels(HotelsInfo h)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            var hotel = obj.HotelsInfoes.Where(x => x.HotelClass == "Star").ToList();
            return View(hotel);
        }
       
        public ActionResult UpdateHotels(int id)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            HotelsInfo t = new HotelsInfo();
            t = obj.HotelsInfoes.Find(id);

            return View(t);
        }
        [HttpPost]
        public ActionResult UpdateHotels(HotelsInfo h)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            if (ModelState.IsValid)
            {
                obj.Entry(h).State = System.Data.EntityState.Modified;
                obj.SaveChanges();
                return RedirectToAction("../Admin/AdminMain");
            }
            return View(h);
        }
        public ActionResult DeleteHotels(int id)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            HotelsInfo t = new HotelsInfo();
            t = obj.HotelsInfoes.Find(id);
            obj.HotelsInfoes.Remove(t);
            obj.SaveChanges();
            return RedirectToAction("../Admin/AdminMain");

        }
        public ActionResult ReservedHotels()
        {
            return View();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InitialFyp.Models;
namespace InitialFyp.Controllers
{
    public class VisitingPlacesController : Controller
    {
        //
        // GET: /VisitingPlaces/

        public ActionResult VisitingPlacesMain()
        {
            return View();
        }
        public ActionResult AddPlace()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddPlace( VisitingPlace v, HttpPostedFileBase file)
        {
            if (file != null)
            {
                MyDbEntities1 obj = new MyDbEntities1();
                string ImageName = System.IO.Path.GetFileName(file.FileName);
                string physicalPath = Server.MapPath("~/VisitingPlaceImage/" + ImageName);
                // save image in folder
                file.SaveAs(physicalPath);
                v.ImageUrl = ImageName;
                obj.VisitingPlaces.Add(v);
                obj.SaveChanges();
                return RedirectToAction("../Admin/AdminMain");
            }
            else
            {
                return RedirectToAction("../Admin/AdminMain");

            }

        }
        public ActionResult ViewPlace()
        {
            MyDbEntities1 obj = new MyDbEntities1();
            VisitingPlace t = new VisitingPlace();
            List<VisitingPlace> mylist = obj.VisitingPlaces.ToList();
            return View(mylist);
        }
        public ActionResult ViewPark(VisitingPlace vp)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            var VisitingPlace = obj.VisitingPlaces.Where(x => x.PlaceType == "Park").ToList();
            return View(VisitingPlace);
        }
        public ActionResult ViewSeaPort(VisitingPlace vp)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            var VisitingPlace = obj.VisitingPlaces.Where(x => x.PlaceType == "SeaPort").ToList();
            return View(VisitingPlace);
        }
        public ActionResult ShoppingMall(VisitingPlace vp)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            var VisitingPlace = obj.VisitingPlaces.Where(x => x.PlaceType == "ShoppingMall").ToList();
            return View(VisitingPlace);
        }
        public ActionResult UpdatePlace(int id)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            VisitingPlace t = new VisitingPlace();
            t = obj.VisitingPlaces.Find(id);

            return View(t);
        }
        [HttpPost]
        public ActionResult UpdatePlace(VisitingPlace t)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            if (ModelState.IsValid)
            {
                obj.Entry(t).State = System.Data.EntityState.Modified;
                obj.SaveChanges();
                return RedirectToAction("../Admin/AdminMain");
            }
            return View(t);
        }
        public ActionResult DeletePlace(int id)
        {
            MyDbEntities1 obj = new MyDbEntities1();
            VisitingPlace t = new VisitingPlace();
            t = obj.VisitingPlaces.Find(id);
            obj.VisitingPlaces.Remove(t);
            obj.SaveChanges();
            return RedirectToAction("../Admin/AdminMain");

        }
    }
}
